#!/bin/bash
#SBATCH --time=00:54:00       # Walltime in hh:mm:ss
#SBATCH --nodes=1             # Number of nodes
#SBATCH --ntasks-per-node=48    # Number of MPI ranks per node
#SBATCH --cpus-per-task=1      # Number of OpenMP threads for each MPI process/rank
#SBATCH --mem=370000           # Per nodes memory request (MB)
#SBATCH --account=IscrB_IPLAS-X
#SBATCH --job-name=modTiFeCuSb
#SBATCH --partition=g100_usr_prod


module purge
module load profile/chem-phys
module load autoload vasp/6.5.1


cp INCAR_mod_orig INCAR
srun vasp_std > scf.out
cp OUTCAR OUTCAR_scf

cp INCAR_mod_nscf INCAR
srun vasp_std > nscf.out
cp OUTCAR OUTCAR_nscf

$HOME/c2x_2.41b/c2x --bxsf EIGENVAL TiFeCuSb.bxsf
